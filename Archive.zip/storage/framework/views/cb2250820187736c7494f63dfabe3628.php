<?php $__env->startSection('title'); ?>
    Road List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="page-header">
                <div class="page-title">
                    <h4>Road List</h4>
                    <h6>Manage your Road</h6>
                </div>
                <div class="page-btn">
                    <a href="<?php echo e(route('road.create')); ?>" class="btn btn-added"><img
                            src="<?php echo e(asset('assets/img/icons/plus.svg')); ?>" alt="img" class="me-1" />Add Road</a>
                </div>
            </div>

            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
                <script>
                    setTimeout(function() {
                        $('.alert-success').fadeOut('slow');
                    }, 2000);
                </script>
            <?php endif; ?>
            <?php if(Session::has('delete')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('delete')); ?>

                </div>
                <script>
                    setTimeout(function() {
                        $('.alert-success').fadeOut('slow');
                    }, 2000);
                </script>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <div class="table-top">
                        <div class="search-set">
                            <div class="search-path">
                                <a class="btn btn-filter" id="filter_search">
                                    <img src="<?php echo e(asset('assets/img/icons/filter.svg')); ?>" alt="img" />
                                    <span><img src="<?php echo e(asset('assets/img/icons/closes.svg')); ?>" alt="img" /></span>
                                </a>
                            </div>
                            <div class="search-input">
                                <a class="btn btn-searchset"><img src="<?php echo e(asset('assets/img/icons/search-white.svg')); ?>"
                                        alt="img" /></a>
                            </div>
                        </div>
                        <div class="wordset">
                            <ul>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="pdf"><img
                                            src="<?php echo e(asset('assets/img/icons/pdf.svg')); ?>" alt="img" /></a>
                                </li>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="excel"><img
                                            src="<?php echo e(asset('assets/img/icons/excel.svg')); ?>" alt="img" /></a>
                                </li>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="print"><img
                                            src="<?php echo e(asset('assets/img/icons/printer.svg')); ?>" alt="img" /></a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table datanew data-table" id="dataTable">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Road List</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script type="text/javascript">
        $(function() {
            $("#dataTable").DataTable().destroy();

            var table = $(".data-table").DataTable({
                processing: true,
                serverSide: true,
                responsive: true,
                ajax: "<?php echo e(route('getRoadList')); ?>",
                columns: [{
                        data: "sl",
                        name: "sl "
                    },
                    {
                        data: "name",
                        name: "name"
                    },
                    {
                        data: "action",
                        name: "action",
                        orderable: false,
                        searchable: false,
                    },
                ],
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mahamudulhasananam/Projects/belal_accounting/resources/views/road/roadList.blade.php ENDPATH**/ ?>
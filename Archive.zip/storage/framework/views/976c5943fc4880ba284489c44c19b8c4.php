<?php $__env->startSection('title'); ?>
    Supplier Payment
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="page-header">
                <div class="page-title">
                    <h4>Supplier Payment</h4>
                    <h6>Make Spplier Payment</h6>
                </div>
            </div>
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
                <script>
                    setTimeout(function() {
                        $('.alert-success').fadeOut('slow');
                    }, 3000);
                </script>
            <?php endif; ?>
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('makeSupplierPayment')); ?>" method="post" id="jqvalidation">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <div class="row">
                            <div class="col-lg-4 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Supplier Name</label>
                                    <input type="hidden" name="supplier_id"
                                        value="<?php echo e($sup_pay_data[0]['supplier']['id']); ?>" />
                                    <input type="text" name="supplier_name"
                                        value="<?php echo e($sup_pay_data[0]['supplier']['supplier_name']); ?>" />
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Purchase Date </label>
                                    <div class="input-groupicon">
                                        <input type="text" value="" name="date" placeholder="DD-MM-YYYY"
                                            id="datetimepicker" />
                                        <div class="addonset">
                                            <img src="<?php echo e(asset('assets/img/icons/calendars.svg')); ?>" alt="img" />
                                        </div>
                                        <div class="text-danger">
                                            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-sm-6 col-12">
                                <ul>
                                    <li class="total">
                                        <div class="col-lg-12 col-sm-6 col-12">
                                            <div class="form-group">
                                                <label>Accounts</label>
                                                <select class="select" name="accounts_id" id="paymentMethod_data">
                                                    <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <option value="<?php echo e($d->id); ?>"
                                                            data-balance="<?php echo e($d->amount); ?>">
                                                            <?php echo e($d->bank_name); ?> (Balance: <?php echo e($d->amount); ?>)
                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <option>No accounts available</option>
                                                    <?php endif; ?>
                                                </select>
                                                <div class="text-danger">
                                                    <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-lg-12 float-md-right">
                                <div class="total-order">
                                    <ul>
                                        <li class="total">
                                            <div class="input-group">
                                                <h4>Due Amount</h4>
                                                <span class="input-group-text">৳</span>

                                                <div>
                                                    <input type="text" value="<?php echo e($dueAmount); ?>" name="due_amount"
                                                        id="due_amount" class="form-control"
                                                        aria-label="Amount (to the nearest dollar)">
                                                </div>

                                            </div>
                                        </li>

                                        <li class="total">
                                            <div class="input-group">
                                                <h4>Paid Amount</h4>
                                                <span class="input-group-text">৳</span>
                                                <div>
                                                    <input type="text" value="0" name="paid_amount" id="paid_amount"
                                                        autocomplete="off" class="form-control"
                                                        aria-label="Amount (to the nearest dollar)">
                                                </div>

                                                <div class="text-danger">
                                                    <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </li>
                                        <span id="error_due"></span>
                                        <li class="total">
                                            <div class="input-group">
                                                <h4>Due</h4>
                                                <span class="input-group-text">৳</span>
                                                <div><input type="text" value="0" name="due" id="due"
                                                        class="form-control" aria-label="Amount (to the nearest dollar)">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <button class="btn btn-submit me-2">Submit</button>
                                <a href="purchaselist.html" class="btn btn-cancel">Cancel</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $('#paymentMethod_data').on('change', function() {
                const selectedAccountId = $(this).val();
                const selectedAccountOption = $(this).find(':selected');
                const accountBalance = parseFloat(selectedAccountOption.data('balance')) || 0;

                // Log for debugging
                console.log('Selected Account ID:', selectedAccountId);
                console.log('Account Balance:', accountBalance);

                const paidAmountInput = $('#paid_amount');
                const errorMsg = $('<span class="text-danger text-end"></span>');
                errorMsg.appendTo($('#error_due'));

                paidAmountInput.on('input', function() {
                    const enteredAmount = parseFloat(paidAmountInput.val()) || 0;

                    // Clear any previous error messages
                    errorMsg.text('');

                    // Check if the entered amount exceeds the balance
                    if (enteredAmount > accountBalance) {
                        errorMsg.text('Paid amount cannot exceed account balance of ৳' +
                            accountBalance);
                        paidAmountInput.val(
                            accountBalance);
                    }
                });
            });
        });
    </script>
    <script src="<?php echo e(asset('assets/js/custom_supplier_payment.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mhanamco/anikafabrics.com/resources/views/makePayment/supplierPayment.blade.php ENDPATH**/ ?>
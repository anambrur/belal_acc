<?php $__env->startSection('title'); ?>
    Users List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="page-header">
                <div class="page-title">
                    <h4>User List</h4>
                    <h6>Manage your User</h6>
                </div>
                <div class="page-btn">
                    <a href="" class="btn btn-added"><img
                            src="<?php echo e(asset('assets/img/icons/plus.svg')); ?>" alt="img" class="me-1" />Add New
                        userlists</a>
                </div>
            </div>

            <hr>
            <?php if(Session::has('success')): ?>
                <div id="success-alert" class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <div class="table-top">
                        <div class="search-set">
                            <div class="search-path">
                                <a class="btn btn-filter" id="filter_search">
                                    <img src="<?php echo e(asset('assets/img/icons/filter.svg')); ?>" alt="img" />
                                    <span><img src="<?php echo e(asset('assets/img/icons/closes.svg')); ?>" alt="img" /></span>
                                </a>
                            </div>
                            <div class="search-input">
                                <a class="btn btn-searchset"><img src="<?php echo e(asset('assets/img/icons/search-white.svg')); ?>"
                                        alt="img" /></a>
                            </div>
                        </div>
                        <div class="wordset">
                            <ul>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="pdf"><img
                                            src="<?php echo e(asset('assets/img/icons/pdf.svg')); ?>" alt="img" /></a>
                                </li>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="excel"><img
                                            src="<?php echo e(asset('assets/img/icons/excel.svg')); ?>" alt="img" /></a>
                                </li>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="print"><img
                                            src="<?php echo e(asset('assets/img/icons/printer.svg')); ?>" alt="img" /></a>
                                </li>
                            </ul>
                        </div>
                    </div>




                    <div class="table-responsive">
                        <table class="table table-border table-hover table-striped datanew">

                            <thead>
                                <tr>
                                    <th class="text-start">SL</th>
                                    <th class="text-start">Name</th>
                                    <th class="text-start">Email</th>
                                    <th class="text-start">Phone</th>
                                    <th class="text-start">Address</th>
                                    <th class="text-start">Status</th>
                                    <th class="text-start">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-start"><?php echo e($loop->iteration); ?></td>
                                    
                                        <td class="text-start"><?php echo e($d->name); ?></td>
                                        <td class="text-start"><?php echo e($d->email); ?></td>
                                        <td class="text-start"><?php echo e($d->phone); ?></td>
                                        <td class="text-start"><?php echo e($d->address); ?></td>
                                        
                                        <td class="text-start">
                                            <select class="select change_product_status"
                                                route="' . config('constant.smAdminSlug') . '/product_status_update' . '"
                                                post_id="' . $v_data->id . '">
                                                <option value="<?php echo e($d->status); ?>" ' . $selected1 . '><?php echo e($d->status); ?>

                                                </option>
                                            </select>

                                        </td>
                                        <td class="text-start">
                                            <div class="d-flex align-items-center">
                                                <a href="<?php echo e(route('user.edit', $d)); ?>">
                                                    <span><i class="fa-solid fa-pen "></i></span>
                                                </a>
                                                <form action="<?php echo e(route('user.destroy', $d)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button onclick="return confirm('Are you sure you want to delete?')"
                                                        class="btn"><i class="fas fa-trash"
                                                            style="color: #FF0000;"></i></button>

                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mhanamco/anikafabrics.com/resources/views/user/index.blade.php ENDPATH**/ ?>
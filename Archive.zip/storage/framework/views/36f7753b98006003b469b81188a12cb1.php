<?php $__env->startSection('title'); ?>
    Purchase Details
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="page-header">
                <div class="page-title">
                    <h4>Purchase Details</h4>
                </div>
            </div>
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Supplier Name</label>
                                    <input type="text" name="suspplier_name"
                                        value="<?php echo e($Pur_details[0]->supplier->supplier_name); ?>">
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Purchase Date </label>
                                    <div class="input-groupicon">
                                        <input type="text" value="<?php echo e($Pur_details[0]->date); ?>" name="date"
                                            placeholder="DD-MM-YYYY" " />
                                                    <div class="addonset">
                                                        <img src="<?php echo e(asset('assets/img/icons/calendars.svg')); ?>" alt="img" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="row">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <thead>

                                                    <tr>
                                                        <th>Product Name</th>
                                                        <th>Quantity</th>
                                                        <th>Purchase Price($)</th>
                                                        <th>Total Price($)</th>
                                                        <th>Sell Price($)</th>
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                       <?php $__empty_1 = true; $__currentLoopData = $Pur_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        
                                        <tr>
                                            <td class="productimgname">
                                                <a class="product-img">
                                                    <img src="<?php echo e(asset('storage/'.$p->product->photo)); ?>" alt="product" />
                                                </a>
                                                <a href="javascript:void(0);"><?php echo e($p->product->product_name); ?></a>
                                            </td>
                                            <td><?php echo e($p->quantity); ?></td>
                                            <td><?php echo e($p->purchase_price); ?></td>
                                            <td><?php echo e($p->quantity * $p->purchase_price); ?></td>
                                            <td><?php echo e($p->sell_price); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>


                                        </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12 float-md-right">
                                        <div class="total-order">
                                            <ul>
                                                <li class="total">
                                                    <div class="input-group">
                                                        <h4>Sub Total</h4>
                                                        <span class="input-group-text"><i
                                                                class="fa-sharp fa-solid fa-bangladeshi-taka-sign"></i></span>
                                                        <input type="text" value="<?php echo e($p->total_price + $p->total_discount); ?>" id="sub_total"
                                                            class="form-control text-end"
                                                            aria-label="Amount (to the nearest dollar)">
                                                    </div>
                                                </li>
                                                <li class="total">
                                                    <div class="input-group">
                                                        <h4>Discount</h4>
                                                        <span class="input-group-text"><i
                                                                class="fa-sharp fa-solid fa-bangladeshi-taka-sign"></i></span>
                                                        <input type="text" value="<?php echo e((int)$p->total_discount); ?>"
                                                            id="discount" class="form-control text-end"
                                                            aria-label="Amount (to the nearest dollar)">
                                                    </div>
                                                </li>
                                                <li class="total">
                                                    <div class="input-group">
                                                        <h4>Total</h4>
                                                        <span class="input-group-text"><i
                                                                class="fa-sharp fa-solid fa-bangladeshi-taka-sign"></i></span>
                                                        <input type="text"
                                                            value="0"
                                                            id="total_amount" class="form-control text-end"
                                                            aria-label="Amount (to the nearest dollar)">
                                                    </div>
                                                </li>
                                                <li class="total">
                                                    <div class="input-group">
                                                        <h4>Paid</h4>
                                                        <span class="input-group-text"><i
                                                                class="fa-sharp fa-solid fa-bangladeshi-taka-sign"></i></span>
                                                        <input type="text" value="<?php echo e((int)$p->paid); ?>"
                                                            class="form-control text-end"
                                                            aria-label="Amount (to the nearest dollar)">
                                                    </div>
                                                </li>
                                                <li class="total">
                                                    <div class="input-group">
                                                        <h4>Due</h4>
                                                        <span class="input-group-text"><i
                                                                class="fa-sharp fa-solid fa-bangladeshi-taka-sign"></i></span>
                                                        <input type="text" value="<?php echo e($p->total_price - $p->paid); ?>"
                                                            class="form-control text-end"
                                                            aria-label="Amount (to the nearest dollar)">
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/js/add_purchase.js')); ?>"></script>
    <script>
        var s = $("#sub_total").val()
        var d = $("#discount").val()
        var total_amount = s-d;
        $("#total_amount").val(total_amount)
        var p = $("#paid_amount").val()
        var due = (g - d) - p;
        $("#due").val(due)
    </script>
<?php $__env->stopPush(); ?>
<script></script>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mhanamco/anikafabrics.com/resources/views/purchase/purchase_show.blade.php ENDPATH**/ ?>
<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>
                <li class="<?php echo e(Route::currentRouteName() == 'dashboard.index' ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa-solid fa-gauge"></i><span>
                            Dashboard</span>
                    </a>
                </li>
                <li class="submenu">
                    <a class="<?php echo e(Route::current()->getPrefix() === '/product' ? 'active' : ''); ?>"
                        href="javascript:void(0);"><i class="fa-brands fa-product-hunt"></i><span>
                            Product</span>
                        <span class="menu-arrow"></span></a>
                    <ul <?php if(Route::current()->getPrefix() === '/product'): ?> style="display:block!important;" <?php endif; ?>>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'product.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('product.index')); ?>">Product List</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'product.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('product.create')); ?>">Add Product</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'category.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('category.index')); ?>">Category List</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'category.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('category.create')); ?>">Add Category</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'unit.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('unit.index')); ?>">Unit List</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'unit.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('unit.create')); ?>">Add Unit</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'company.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('company.index')); ?>">Company List</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'company.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('company.create')); ?>">Add Company</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'company.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('batch.index')); ?>">Batch List</a></li>

                    </ul>
                </li>


                <li class="submenu">
                    <a class="<?php echo e(Route::current()->getPrefix() === '/sell' ? 'active' : ''); ?>"
                        href="javascript:void(0);"><i class="fa-solid fa-cart-shopping"></i><span>
                            Sales</span>
                        <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'sell.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('sell.index')); ?>">Sales List</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'sell.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('sell.create')); ?>">Sells Create</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'sellsReturn.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('sellsReturn.index')); ?>">Sales Return List</a></li>
                        <li>
                            <a class="<?php echo e(Route::currentRouteName() === 'sellsReturn.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('sellsReturn.create')); ?>">New Sales Return</a>
                        </li>
                    </ul>
                </li>



                <li class="submenu">
                    <a class="<?php echo e(Route::current()->getPrefix() === '/purchase' ? 'active' : ''); ?>"
                        href="javascript:void(0);"><i class="fa-brands fa-product-hunt"></i><span>
                            Purchase</span>
                        <span class="menu-arrow"></span></a>
                    <ul <?php if(Route::current()->getPrefix() === '/purchase'): ?> style="display:block!important;" <?php endif; ?>>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'purchase.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('purchase.index')); ?>">Purchase List</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'purchase.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('purchase.create')); ?>">Add Purchase</a></li>
                    </ul>
                </li>



                <li class="submenu">
                    <a class="<?php echo e(Route::current()->getPrefix() === '/expense' ? 'active' : ''); ?>"
                        href="javascript:void(0);"><i class="fa-solid fa-money-bill"></i><span>
                            Expense</span>
                        <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'expense.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('expense.index')); ?>">Expense List</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'expense.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('expense.create')); ?>">Add Expense</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'expenseCategory.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('expenseCategory.index')); ?>">Expense Category List</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'expenseCategory.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('expenseCategory.create')); ?>">Expense Category Add</a></li>
                    </ul>
                </li>


                
                <li class="submenu">
                    <a class="<?php echo e(Route::current()->getPrefix() === '/accounts' ? 'active' : ''); ?>"
                        href="javascript:void(0);"><i class="fa-solid fa-money-bill"></i><span>
                            Acccounting</span>
                        <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'accounts.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('accounts.index')); ?>">Accounts</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'accounts.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('accounts.create')); ?>">Add Accounts</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'balanceAdjustmentView' ? 'active' : ''); ?>"
                                href="<?php echo e(route('balanceAdjustmentView')); ?>">Balance Adjustment</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'balanceTransferView' ? 'active' : ''); ?>"
                                href="<?php echo e(route('balanceTransferView')); ?>">Balance Transfer</a></li>
                    </ul>
                </li>








                <li class="submenu">
                    <a class="<?php echo e(Route::current()->getPrefix() === '/people' ? 'active' : ''); ?>"
                        href="javascript:void(0);"><i class="fa-solid fa-person"></i><span>
                            People</span>
                        <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'customer.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('customer.index')); ?>">Customer List</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'customer.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('customer.create')); ?>">Add Customer </a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() == 'supplier.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('supplier.index')); ?>">Supplier List</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() == 'supplier.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('supplier.create')); ?>">Add Supplier </a></li>
                        <li><a href="userlist.html">User List</a></li>
                        <li><a href="adduser.html">Add User</a></li>
                        <li><a href="storelist.html">Store List</a></li>
                        <li><a href="addstore.html">Add Store</a></li>
                    </ul>
                </li>




                <li class="submenu">
                    <a class="<?php echo e(Route::current()->getPrefix() === '/profit' ? 'active' : ''); ?>"
                        href="javascript:void(0);"><i class="fa-regular fa-flag"></i><span>
                            Report</span>
                        <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'profitCalculation' ? 'active' : ''); ?>"
                                href="<?php echo e(route('profitCalculation')); ?>">Daily Report</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'dateFilter' ? 'active' : ''); ?> d-none"
                                href="<?php echo e(route('profitCalculation')); ?>">Profit report</a></li>

                        <li><a class="<?php echo e(Route::currentRouteName() === 'balance_sheet_view' ? 'active' : ''); ?>"
                                href="<?php echo e(route('balance_sheet_view')); ?>">Balance Sheet</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'collectionList' ? 'active' : ''); ?>"
                                href="<?php echo e(route('collectionList')); ?>">Collection Report</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'sellsReportList' ? 'active' : ''); ?>"
                                href="<?php echo e(route('sellsReportList')); ?>">Sell Report</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'purchaseReportList' ? 'active' : ''); ?>"
                                href="<?php echo e(route('purchaseReportList')); ?>">Purchase Report</a></li>


                    </ul>
                </li>



                <li class="submenu">
                    <a class="<?php echo e(Route::current()->getPrefix() === '/loan' ? 'active' : ''); ?>"
                        href="javascript:void(0);"><i class="fa-regular fa-flag"></i><span>
                            Loan</span>
                        <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'loan.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('loan.index')); ?>">Loan List</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'loan.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('loan.create')); ?>">Loan Add</a></li>

                    </ul>
                </li>



                <li class="submenu">
                    <a href="javascript:void(0);"><i class="fa-solid fa-user"></i><span>
                            Attendence</span>
                        <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'user.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('showAttendence')); ?>">Show Attendence </a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'user.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('user.index')); ?>">Users List</a></li>
                    </ul>
                </li>
                <li class="submenu">
                    <a href="javascript:void(0);"><i class="fa-solid fa-user"></i><span>
                            Users</span>
                        <span class="menu-arrow"></span></a>
                    <ul>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'user.create' ? 'active' : ''); ?>"
                                href="<?php echo e(route('user.create')); ?>">New User </a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'user.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('user.index')); ?>">Users List</a></li>
                    </ul>
                </li>



                <li class="submenu">
                    <a class="<?php echo e(Route::current()->getPrefix() === '/payment' ? 'active' : ''); ?>"
                        href="javascript:void(0);"><i class="fa-solid fa-gear"></i><span>
                            Settings</span>
                        <span class="menu-arrow"></span></a>
                    <ul>
                        
                        <li><a class="<?php echo e(Route::currentRouteName() === 'location.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('location.index')); ?>">Location Settings</a></li>
                        <li><a class="<?php echo e(Route::currentRouteName() === 'road.index' ? 'active' : ''); ?>"
                                href="<?php echo e(route('road.index')); ?>">Road Settion</a></li>
                        
                    </ul>
                </li>




            </ul>
        </div>
    </div>
</div>
<?php /**PATH D:\Office\Personal\belal_accounting\resources\views/inc/sidebar.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Customer Ledger — <?php echo e($customer->customer_name); ?></title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 11px;
            color: #222;
        }

        h1 {
            font-size: 18px;
            margin: 0 0 4px;
        }

        .meta {
            margin-bottom: 16px;
            line-height: 1.5;
        }

        .summary {
            width: 100%;
            margin-bottom: 16px;
            border-collapse: collapse;
        }

        .summary td {
            border: 1px solid #ccc;
            padding: 8px;
            width: 25%;
        }

        .summary .label {
            font-size: 10px;
            color: #666;
        }

        .summary .value {
            font-size: 13px;
            font-weight: bold;
        }

        table.ledger {
            width: 100%;
            border-collapse: collapse;
        }

        table.ledger th,
        table.ledger td {
            border: 1px solid #ccc;
            padding: 6px 8px;
        }

        table.ledger th {
            background: #e9ecef;
            text-align: left;
        }

        .text-end {
            text-align: right;
        }

        .text-danger {
            color: #c0392b;
        }

        .text-success {
            color: #1e8449;
        }

        .muted {
            color: #888;
        }

        .footer {
            margin-top: 18px;
            font-size: 9px;
            color: #666;
        }
    </style>
</head>

<body>
    <h1>Customer Ledger</h1>
    <div class="meta">
        <strong><?php echo e($customer->customer_name); ?></strong><br>
        Mobile: <?php echo e($customer->phone); ?><br>
        Address: <?php echo e($customer->road->name ?? '—'); ?>, <?php echo e($customer->location->address ?? '—'); ?><br>
        Date Range:
        <?php if($isFiltered): ?>
            <?php echo e($startDate ? \Carbon\Carbon::parse($startDate)->format('d M Y') : '…'); ?>

            —
            <?php echo e($endDate ? \Carbon\Carbon::parse($endDate)->format('d M Y') : '…'); ?>

        <?php else: ?>
            All time
        <?php endif; ?>
        <br>
        Generated: <?php echo e($generatedAt->format('d M Y H:i')); ?>

    </div>

    <table class="summary">
        <tr>
            <?php if($isFiltered): ?>
                <td>
                    <div class="label">Opening Balance</div>
                    <div class="value <?php echo e($openingBalance > 0 ? 'text-danger' : 'text-success'); ?>">
                        <?php echo e(number_format($openingBalance, 2)); ?>

                    </div>
                </td>
            <?php endif; ?>
            <td>
                <div class="label">Total Debit</div>
                <div class="value text-danger"><?php echo e(number_format($debitTotal, 2)); ?></div>
            </td>
            <td>
                <div class="label">Total Credit</div>
                <div class="value text-success"><?php echo e(number_format($creditTotal, 2)); ?></div>
            </td>
            <td>
                <div class="label">Closing Due</div>
                <div class="value <?php echo e($dueTotal > 0 ? 'text-danger' : 'text-success'); ?>">
                    <?php echo e(number_format($dueTotal, 2)); ?>

                </div>
            </td>
        </tr>
    </table>

    <table class="ledger">
        <thead>
            <tr>
                <th>#</th>
                <th>Date</th>
                <th>Operation</th>
                <th class="text-end">Debit</th>
                <th class="text-end">Credit</th>
                <th class="text-end">Balance</th>
            </tr>
        </thead>
        <tbody>
            <?php if($isFiltered && abs($openingBalance) > 0.00001): ?>
                <tr>
                    <td>—</td>
                    <td><?php echo e($startDate ? \Carbon\Carbon::parse($startDate)->format('d M Y') : '—'); ?></td>
                    <td>Opening Balance</td>
                    <td class="text-end muted">—</td>
                    <td class="text-end muted">—</td>
                    <td class="text-end <?php echo e($openingBalance > 0 ? 'text-danger' : 'text-success'); ?>">
                        <?php echo e(number_format($openingBalance, 2)); ?>

                    </td>
                </tr>
            <?php endif; ?>

            <?php $__empty_1 = true; $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($i + 1); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($d->date)->format('d M Y')); ?></td>
                    <td>
                        <?php if($d->type === 'sale'): ?>
                            Sale — <?php echo e($d->reference); ?>

                        <?php elseif($d->type === 'return'): ?>
                            Return — <?php echo e($d->reference); ?>

                        <?php else: ?>
                            <?php echo e($d->reference); ?>

                        <?php endif; ?>
                    </td>
                    <td class="text-end">
                        <?php echo e($d->debit > 0 ? number_format($d->debit, 2) : '—'); ?>

                    </td>
                    <td class="text-end">
                        <?php echo e($d->credit > 0 ? number_format($d->credit, 2) : '—'); ?>

                    </td>
                    <td class="text-end <?php echo e($d->running_balance > 0 ? 'text-danger' : 'text-success'); ?>">
                        <?php echo e(number_format($d->running_balance, 2)); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" style="text-align:center;">No records found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" class="text-end"><strong>Totals</strong></td>
                <td class="text-end text-danger"><strong><?php echo e(number_format($debitTotal, 2)); ?></strong></td>
                <td class="text-end text-success"><strong><?php echo e(number_format($creditTotal, 2)); ?></strong></td>
                <td class="text-end <?php echo e($dueTotal > 0 ? 'text-danger' : 'text-success'); ?>">
                    <strong><?php echo e(number_format($dueTotal, 2)); ?></strong>
                </td>
            </tr>
        </tfoot>
    </table>

    <div class="footer">
        Formula: Due = Sales − Returns − Payments. Positive balance means customer owes.
    </div>
</body>

</html>
<?php /**PATH /Users/mahamudulhasananam/Projects/belal_accounting/resources/views/customer/cus_ledger_pdf.blade.php ENDPATH**/ ?>
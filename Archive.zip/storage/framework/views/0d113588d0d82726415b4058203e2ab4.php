<?php $__env->startSection('title'); ?>
    Sell Edit
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="page-header">
                <div class="page-title">
                    <h4>Sell edit-sales</h4>
                    <h6>Add/Update Purchase</h6>
                </div>
            </div>
            <form action="<?php echo e(route('sell.update', $sell_details[0]->invoice_id)); ?>" method="post" id="jqvalidation">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="card">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-lg-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Customer Name</label>
                                    <input type="text" name="customer_name"
                                        value="<?php echo e($sell_details[0]->customer->customer_name); ?> (<?php echo e($sell_details[0]->customer->location->address); ?>)"
                                        readonly>
                                    <input type="hidden" name="customer_id" value="<?php echo e($sell_details[0]->customer_id); ?>">
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Purchase Date </label>
                                    <div class="input-groupicon">
                                        <input type="text" value="<?php echo e($sell_details[0]->date); ?>" name="date"
                                            placeholder="DD-MM-YYYY" id="datetimepicker" />
                                        <div class="addonset">
                                            <img src="<?php echo e(asset('assets/img/icons/calendars.svg')); ?>" alt="img" />
                                        </div>
                                        <div class="text-danger">
                                            <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="table-responsive table-bordered">
                                <table class="table" id="myTable">
                                    <thead>

                                    </thead>
                                    <tbody class="vertical-align: middle" id="tBody">
                                        <?php $m = 1; ?>
                                        <?php $__empty_1 = true; $__currentLoopData = $sell_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=> $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            
                                            <?php $m += $k; ?>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12 float-md-right">
                                <div class="total-order">
                                    <ul>
                                        <li class="total">
                                            <div class="input-group">
                                                <h4>Sub Total</h4>
                                                <span class="input-group-text">৳</span>

                                                <div>
                                                    <input type="text" value="<?php echo e($p->total_price); ?>" name="sub_total"
                                                        id="sub_total" class="form-control"
                                                        aria-label="Amount (to the nearest dollar)">
                                                </div>

                                            </div>
                                        </li>
                                        <li class="total">
                                            <div class="input-group">
                                                <h4>Discount</h4>
                                                <span class="input-group-text">৳</span>
                                                <div>
                                                    <input type="text" value="<?php echo e($p->total_discount); ?>"
                                                        name="discount_price" id="discount_price" class="form-control"
                                                        aria-label="Amount (to the nearest dollar)">
                                                </div>

                                            </div>
                                        </li>
                                        <li class="total">
                                            <div class="input-group">
                                                <h4>Total</h4>
                                                <span class="input-group-text">৳</span>
                                                <div>
                                                    <input type="text" value="0" name="total_price" id="total_price"
                                                        class="form-control" aria-label="Amount (to the nearest dollar)">
                                                </div>
                                                <div class="text-danger">
                                                    <?php $__errorArgs = ['total_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="total">
                                            <div class="input-group">
                                                <h4>Paid</h4>
                                                <span class="input-group-text">৳</span>

                                                <div>
                                                    <input type="text" value="<?php echo e($sell_details[0]->paid_amount); ?>"
                                                        name="paid_amount" id="paid_amount" class="form-control"
                                                        aria-label="Amount (to the nearest dollar)">
                                                </div>
                                                <div class="text-danger">
                                                    <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </li>
                                        <li class="total">
                                            <div class="input-group">
                                                <h4>Due</h4>
                                                <span class="input-group-text">৳</span>
                                                <div><input type="text" value="0" name="due" id="due"
                                                        class="form-control" aria-label="Amount (to the nearest dollar)">
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>




                            <div class="col-6">
                                <div class="form-group">
                                    <select class="select" name="accounts_id" id="paymentMethod_data">
                                        <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <option value="<?php echo e($d->id); ?>">
                                                <?php echo e($d->bank_name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                        <div class="addonset">
                                            <img src="<?php echo e(asset('assets/img/icons/scanners.svg')); ?>" alt="img" />
                                        </div>
                                    </select>
                                    <div class="text-danger">
                                        <?php $__errorArgs = ['paymentMethod_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-lg-12">
                                <hr>
                                <button class="btn btn-submit me-2">Submit</button>
                                <a href="purchaselist.html" class="btn btn-cancel">Cancel</a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        $(document).ready(function() {
            $('#datetimepicker').datetimepicker({
                format: 'Y-m-d',
                timepicker: false,
                scrollInput: false
            });
        });
        let laram = <?php echo e($m); ?>


        var g = $("#sub_total").val()
        var d = $("#discount_price").val()
        var total_price = g - d
        $("#total_price").val(total_price)

        var p = $("#paid_amount").val()
        var due = total_price - p
        $("#due").val(due)
    </script>
    <script src="<?php echo e(asset('assets/js/custom_pos_sell.js')); ?>"></script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mhanamco/anikafabrics.com/resources/views/sell/sellEdit.blade.php ENDPATH**/ ?>
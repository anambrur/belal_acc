<?php $__env->startSection('title'); ?>
    Sell Create
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <form action="<?php echo e(route('sell.store')); ?>" method="post" id="jqvalidation">
                <div class="row ">
                    <?php echo csrf_field(); ?>
                    <div class="col-lg-4 col-sm-12">
                        <div class="order-list">
                            <div class="orderid">
                                <h4>Sells Create</h4>
                                <h5>Invoice id : MT <?php echo e($invoice_id); ?></h5>
                            </div>
                        </div>
                        <div class="card card-order">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12">
                                        <a href="<?php echo e(route('customer.create')); ?>" class="btn btn-adds"
                                            data-bs-target="#create"><i class="fa fa-plus me-2"></i>Add
                                            Customer</a>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <select class="select" name="customer_id">
                                                <option value="">Choose Customer</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($d->id); ?>">
                                                        <?php echo e($d->customer_name); ?> (<?php echo e($d->location->address); ?>)</option>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
                                            </select>
                                            
                                            <div class="text-danger">
                                                <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo e($message); ?>

                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                            <div class="input-groupicon">
                                                <input type="text" value="" name="date" placeholder="DD-MM-YYYY"
                                                    id="datetimepicker" />
                                                <div class="addonset">
                                                    <img src="<?php echo e(asset('assets/img/icons/calendars.svg')); ?>"
                                                        alt="img" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="col-12">
                                        <div class="form-group">
                                            <select class="select" name="accounts_id" id="paymentMethod_data">
                                                <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($d->id); ?>">
                                                        <?php echo e($d->bank_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
                                                <div class="addonset">
                                                    <img src="<?php echo e(asset('assets/img/icons/scanners.svg')); ?>"
                                                        alt="img" />
                                                </div>
                                            </select>
                                            <div class="text-danger">
                                                <?php $__errorArgs = ['paymentMethod_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo e($message); ?>

                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="split-card"></div>

                        </div>
                    </div>
                    <div class="col-lg-8 col-sm-12 tabs_wrapper">
                        <div class="tabs_container">
                            <div class="tab_content active" data-tab="fruits">
                                <div class="row">
                                    <div class="card">
                                        <div class="card-body">

                                            <div class="row">
                                                <div class="col-lg-6 mt-auto">
                                                    <ul>
                                                        <li class="total">

                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="col-lg-12">
                                                    <div class="total-order">
                                                        <ul>
                                                            <li class="total">
                                                                <div class="input-group">
                                                                    <h4>Sub Total</h4>
                                                                    <span class="input-group-text">৳</span>

                                                                    <div>
                                                                        <input type="text" value="0"
                                                                            name="sub_total" id="sub_total"
                                                                            class="form-control
                                                                            aria-label="Amount
                                                                            (to the nearest dollar)">
                                                                    </div>

                                                                </div>
                                                            </li>
                                                            <li class="total">
                                                                <div class="input-group">
                                                                    <h4>Discount</h4>
                                                                    <span class="input-group-text">৳</span>
                                                                    <div>
                                                                        <input type="text" value="0"
                                                                            name="discount_price" id="discount_price"
                                                                            class="form-control"
                                                                            aria-label="Amount (to the nearest dollar)">
                                                                    </div>
                                                                    <div class="text-danger">
                                                                        <?php $__errorArgs = ['discount_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <?php echo e($message); ?>

                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>

                                                                </div>
                                                            </li>
                                                            <li class="total">
                                                                <div class="input-group">
                                                                    <h4>Total</h4>
                                                                    <span class="input-group-text">৳</span>
                                                                    <div>
                                                                        <input type="text" value="0"
                                                                            name="total_price" id="total_price"
                                                                            class="form-control"
                                                                            aria-label="Amount (to the nearest dollar)">
                                                                    </div>
                                                                    <div class="text-danger">
                                                                        <?php $__errorArgs = ['total_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <?php echo e($message); ?>

                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                </div>
                                                            </li>

                                                            <li class="total">
                                                                <div class="input-group">
                                                                    <h4>Paid</h4>
                                                                    <span class="input-group-text">৳</span>

                                                                    <div>
                                                                        <input type="text" value="0"
                                                                            name="paid_amount" id="paid_amount"
                                                                            class="form-control"
                                                                            aria-label="Amount (to the nearest dollar)">
                                                                    </div>
                                                                    <div class="text-danger">
                                                                        <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <?php echo e($message); ?>

                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                </div>
                                                            </li>

                                                            <li class="total">
                                                                <div class="input-group">
                                                                    <h4>Due</h4>
                                                                    <span class="input-group-text">৳</span>
                                                                    <div><input type="text" value="0"
                                                                            name="due" id="due"
                                                                            class="form-control"
                                                                            aria-label="Amount (to the nearest dollar)">
                                                                    </div>
                                                                </div>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="row">

                                                <div class="col-lg-12 text-end">
                                                    <hr>
                                                    <button class="btn btn-submit me-2">Submit</button>

                                                    <a href="" class="btn btn-cancel">Cancel</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('assets/js/custom_pos_sell.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mhanamco/anikafabrics.com/resources/views/sell/sellAdd.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?>
    Accounts List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="page-header">
                <div class="page-title">
                    <h4>Accounts</h4>
                    <h6>Manage your Accounts</h6>
                </div>
                <div class="page-btn">
                    <a href="<?php echo e(route('accounts.create')); ?>" class="btn btn-added"><img
                            src="<?php echo e(asset('assets/img/icons/plus.svg')); ?>" alt="img" class="me-1" />Add Accounts</a>
                </div>
            </div>

            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
                <script>
                    setTimeout(function() {
                        $('.alert-success').fadeOut('slow');
                    }, 2000);
                </script>
            <?php endif; ?>
            <?php if(Session::has('delete')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('delete')); ?>

                </div>
                <script>
                    setTimeout(function() {
                        $('.alert-success').fadeOut('slow');
                    }, 2000);
                </script>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <div class="table-top">
                        <div class="search-set">
                            <div class="search-path">
                                <a class="btn btn-filter" id="filter_search">
                                    <img src="<?php echo e(asset('assets/img/icons/filter.svg')); ?>" alt="img" />
                                    <span><img src="<?php echo e(asset('assets/img/icons/closes.svg')); ?>" alt="img" /></span>
                                </a>
                            </div>
                            <div class="search-input">
                                <a class="btn btn-searchset"><img src="<?php echo e(asset('assets/img/icons/search-white.svg')); ?>"
                                        alt="img" /></a>
                            </div>
                        </div>
                        <div class="wordset">
                            <ul>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="pdf"><img
                                            src="<?php echo e(asset('assets/img/icons/pdf.svg')); ?>" alt="img" /></a>
                                </li>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="excel"><img
                                            src="<?php echo e(asset('assets/img/icons/excel.svg')); ?>" alt="img" /></a>
                                </li>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="print"><img
                                            src="<?php echo e(asset('assets/img/icons/printer.svg')); ?>" alt="img" /></a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-striped" id="">
                            <?php
                                $netAmount = getAccountsBalance();
                                // dd($netAmount);
                            ?>
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Bank Name</th>
                                    <th>Branch Name</th>
                                    <th>Account No</th>
                                    <th>Abailable Balance</th>
                                    <th>Date</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $accountsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accounts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td>
                                            <?php echo e($loop->iteration); ?>

                                        </td>

                                        <td>
                                            <?php echo e($accounts->bank_name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($accounts->branch_name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($accounts->account_number); ?>

                                        </td>
                                        <td>
                                            <?php echo e($accounts->amount); ?>

                                        </td>
                                        <td>
                                            <?php echo e($accounts->date); ?>

                                        </td>

                                        <td>
                                            <?php echo e($accounts->description); ?>

                                        </td>

                                        <td>
                                            <span class="badge <?php echo e($accounts->status == 1 ? 'bg-success' : 'bg-danger'); ?>">
                                                <?php echo e($accounts->status == 1 ? 'Active' : 'Inactive'); ?>

                                            </span>
                                        </td>


                                        <td>
                                            <div class="d-flex align-items-center">
                                                <a href="<?php echo e(route('accounts.edit', $accounts)); ?>">
                                                    <span><i class="fa-solid fa-pen "></i></span>
                                                </a>
                                                <form action="<?php echo e(route('accounts.destroy', $accounts)); ?>" method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button onclick="return confirm('Are you sure you want to delete?')"
                                                        class="btn"><i class="fas fa-trash"
                                                            style="color: #FF0000;"></i></button>

                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td class="text-center" colspan="9">Category not Found</td>
                                    </tr>
                                <?php endif; ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mahamudulhasananam/Projects/belal_accounting/resources/views/accounts/accountsList.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?>
    Balance Sheet
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="card">
                <div class="card-body">
                    <div class="table-top">
                        <div class="row" style="width: 100%">
                            <div class="col-lg-3 col-sm-6 col-12">
                                <h6>Customer Ledger List</h6>
                                <p class="m-0">Date: <?php echo e(date('d M Y')); ?></p>
                                <p class="m-0">From Date:</p>
                                <p class="m-0">Thru Date:</p>
                            </div>
                            <div class="col-lg-5 col-sm-6 col-12">
                                <h5>Moon Trading</h5>
                                <h6>Belal Hosain</h6>
                                <p class="m-0"><strong>Mobile:</strong>01723074844 </p>
                                <p class="m-0"> <strong>Address:</strong>Central Road,Payrachottor,Rangpur</p>

                            </div>
                            
                        </div>
                    </div>
                    <hr>
                    <div class="table-top">
                        <div class="search-set">
                            <div class="search-path">
                                <a class="btn btn-filter" id="filter_search">
                                    <img src="<?php echo e(asset('assets/img/icons/filter.svg')); ?>" alt="img" />
                                    <span><img src="<?php echo e(asset('assets/img/icons/closes.svg')); ?>" alt="img" /></span>
                                </a>
                            </div>
                            <div class="search-input">
                                <a class="btn btn-searchset"><img src="<?php echo e(asset('assets/img/icons/search-white.svg')); ?>"
                                        alt="img" /></a>
                            </div>
                        </div>
                        <div class="wordset">
                            <ul>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="pdf"><img
                                            src="<?php echo e(asset('assets/img/icons/pdf.svg')); ?>" alt="img" /></a>
                                </li>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="excel"><img
                                            src="<?php echo e(asset('assets/img/icons/excel.svg')); ?>" alt="img" /></a>
                                </li>
                                <li>
                                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="print"><img
                                            src="<?php echo e(asset('assets/img/icons/printer.svg')); ?>" alt="img" /></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <hr>

                    <div class="table-responsive">
                        <table class="table datanew data-table table-striped" id="dataTable">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Customer Name</th>
                                    <th>Date</th>
                                    <th>Debet</th>
                                    <th>Cradit</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#dataTable").DataTable().destroy();
            var table = $(".data-table").DataTable({
                processing: true,
                serverSide: true,
                responsive: true,
                ajax: {
                    url: "<?php echo e(route('blanceSheetTable')); ?>",
                    // data: function(d) {
                    //     d.filter_company = $('#filter_company').val();
                    //     d.filter_category = $('#filter_category').val();
                    //     d.filter_batch = $('#filter_batch').val();
                    // }
                },

                columns: [{
                        data: "sl",
                        name: "sl"
                    },
                    {
                        data: "customer.customer_name",
                        name: "customer.customer_name"
                    },
                    {
                        data: "date",
                        name: "date"
                    },
                    {
                        data: "paid_amount",
                        name: "paid_amount"
                    },
                    {
                        data: "total_price",
                        name: "total_price"
                    },
                   

                    // {
                    //     data: "action",
                    //     name: "action",
                    //     orderable: false,
                    //     searchable: false,
                    // },
                ],
            });


            // $(".select").select2();
            // $('#filter_company, #filter_category, #filter_batch').change(function() {
            //     table.draw();
            // });


        });
    </script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mahamudulhasananam/Projects/belal_accounting/resources/views/accounting/balanceSheet.blade.php ENDPATH**/ ?>
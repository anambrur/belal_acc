<?php $__env->startSection('title'); ?>
    Edit Customer Payment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="page-header">
                <div class="page-title">
                    <h4>Edit Payment</h4>
                    <h6>Update customer payment details</h6>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('customer.payment.update', $payment->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        
                        <div class="row">
                            <div class="col-lg-12 col-sm-12">
                                <div class="form-group">
                                    <label>Customer Name</label>
                                    <input type="text" class="form-control" value="<?php echo e($customer->customer_name); ?>" readonly>
                                    <input type="hidden" name="customer_id" value="<?php echo e($customer->id); ?>">
                                </div>
                            </div>
                            
                            <div class="col-lg-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Payment Amount</label>
                                    <input type="number" step="0.01" name="paid_amount" class="form-control" 
                                           value="<?php echo e(old('paid_amount', $payment->amount)); ?>" required>
                                </div>
                            </div>
                            
                            <div class="col-lg-6 col-sm-6 col-12">
                                <div class="form-group">
                                    <label>Payment Date</label>
                                    <input type="date" name="date" class="form-control" 
                                           value="<?php echo e(old('date', $payment->date->format('Y-m-d'))); ?>" required>
                                </div>
                            </div>
                            
                            <div class="col-lg-12 col-sm-12">
                                <div class="form-group">
                                    <label>Payment Account</label>
                                    <select class="select" name="accounts_id" required>
                                        <option value="">Select Account</option>
                                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($account->id); ?>" 
                                                <?php echo e(old('accounts_id', $payment->accounts_id) == $account->id ? 'selected' : ''); ?>>
                                                <?php echo e($account->name); ?> - <?php echo e(number_format($account->amount)); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            
                            <?php if(isset($payment->payment_for)): ?>
                            <div class="col-lg-12 col-sm-12">
                                <div class="form-group">
                                    <label>Payment For</label>
                                    <input type="text" name="payment_for" class="form-control" 
                                           value="<?php echo e(old('payment_for', $payment->payment_for)); ?>">
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <div class="col-lg-12">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary">Update Payment</button>
                                    <a href="<?php echo e(route('customer.show', $customer->id)); ?>" class="btn btn-secondary">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mahamudulhasananam/Projects/belal_account/resources/views/customer/edit_customer_payment.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0" />
    <meta name="description" content="POS - Bootstrap Admin Template" />
    <meta name="keywords"
        content="admin, estimates, bootstrap, business, corporate, creative, management, minimal, modern,  html5, responsive" />
    <meta name="author" content="Dreamguys - Bootstrap Admin Template" />
    <meta name="robots" content="noindex, nofollow" />

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <?php echo $__env->yieldContent('csrf-token'); ?>

    <link rel="shortcut icon" type="image/x-icon" href="assets/img/logo-small.png" />

    <link rel="stylesheet" media='screen,print' href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>" />

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.bootstrap4.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dataTables.dataTables.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatable/buttons.bootstrap4.min.css')); ?>" />


    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/fontawesome.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/all.min.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.datetimepicker.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/error.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" />

    <?php $__env->startPush('css'); ?>
        <style>
            .dt-button {
                background: #ff9f43 !important;
                padding: 3px 15px;
                color: #fff;
                font-weight: 700;
                font-size: 14px;
                border-radius: 4px;
            }
        </style>
    <?php $__env->stopPush(); ?>


    <?php echo $__env->yieldPushContent('css'); ?>



</head>

<body>
    

    <div class="main-wrapper">

        <?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

    </div>

    <script src="<?php echo e(asset('assets/js/base_url.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.validate.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('assets/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/datatable/vfs_fonts.js')); ?>"></script>


    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/plugins/apexchart/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/apexchart/chart-data.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.datetimepicker.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH D:\Office\Personal\belal_accounting\resources\views/layout.blade.php ENDPATH**/ ?>
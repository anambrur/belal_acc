<?php $__env->startSection('title'); ?>
    Customer Ledger
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="card">
                <div class="card-body">

                    
                    <div class="card mb-4">
                        <div class="card-body">
                            <form action="<?php echo e(route('customer.show', $customer->id)); ?>" method="GET">
                                <div class="row g-3 align-items-end">

                                    <div class="col-md-3">
                                        <label for="start_date" class="form-label">Start Date</label>
                                        <input type="date" class="form-control" id="start_date" name="start_date"
                                            value="<?php echo e($startDate ?? ''); ?>">
                                    </div>

                                    <div class="col-md-3">
                                        <label for="end_date" class="form-label">End Date</label>
                                        <input type="date" class="form-control" id="end_date" name="end_date"
                                            value="<?php echo e($endDate ?? ''); ?>">
                                    </div>
                                    

                                    
                                    <div class="col-md-2">
                                        <label for="per_page" class="form-label">Show Entries</label>
                                        <select name="per_page" id="per_page" class="form-control">
                                            <?php $__currentLoopData = [25, 50, 100, 200]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($option); ?>"
                                                    <?php echo e($perPage == $option ? 'selected' : ''); ?>>
                                                    <?php echo e($option); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-md-2">
                                        <button type="submit" class="btn btn-primary w-100">
                                            <i class="fa fa-filter me-1"></i> Filter
                                        </button>
                                    </div>

                                    <div class="col-md-2">
                                        <a href="<?php echo e(route('customer.show', $customer->id)); ?>"
                                            class="btn btn-secondary w-100">
                                            <i class="fa fa-refresh me-1"></i> Reset
                                        </a>
                                    </div>

                                </div>
                            </form>
                        </div>
                    </div>

                    
                    <div class="mb-3">
                        <div class="row">
                            <div class="col-lg-6">
                                <h6 class="mb-1">Customer Name: <strong><?php echo e($customer->customer_name); ?></strong></h6>
                                <p class="mb-0">Mobile: <?php echo e($customer->phone); ?></p>
                                <p class="mb-0">Address: <?php echo e($customer->road->name); ?>, <?php echo e($customer->location->address); ?>

                                </p>
                            </div>
                            <div class="col-lg-6 text-lg-end">
                                <p class="mb-0">
                                    <strong>Date Range:</strong>
                                    <?php echo e(\Carbon\Carbon::parse($startDate)->format('M d, Y')); ?> —
                                    <?php echo e(\Carbon\Carbon::parse($endDate)->format('M d, Y')); ?>

                                </p>
                                <p class="mb-0">
                                    <strong>Total Records:</strong> <?php echo e($ledgerPaginator->total()); ?>

                                </p>
                            </div>
                        </div>
                    </div>

                    
                    <div class="table-responsive">
                        
                        <table class="table table-striped table-bordered table-hover">
                            <thead class="table-primary">
                                <tr>
                                    <th width="50">#</th>
                                    <th>Date</th>
                                    <th>Operation</th>
                                    <th class="text-end">Debit</th>
                                    <th class="text-end">Credit</th>
                                    <th class="text-end">Balance</th>
                                    <th width="100">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $counter = ($ledgerPaginator->currentPage() - 1) * $ledgerPaginator->perPage() + 1;
                                ?>

                                <?php $__empty_1 = true; $__currentLoopData = $ledgerPaginator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($counter++); ?></td>

                                        <td><?php echo e(\Carbon\Carbon::parse($d->date)->format('M d, Y')); ?></td>

                                        <td>
                                            <?php if(isset($d->total_price) && $d->total_price > 0): ?>
                                                <span class="badge bg-info text-dark">Sale</span>
                                                Invoice: <strong><?php echo e($d->invoice_id); ?></strong>
                                            <?php elseif(isset($d->total_amount) && $d->total_amount > 0): ?>
                                                <span class="badge bg-warning text-dark">Return</span>
                                                Product Return
                                            <?php else: ?>
                                                <span class="badge bg-success">Payment</span>
                                                <?php if(!empty($d->payment_for)): ?>
                                                    — <?php echo e($d->payment_for); ?>

                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td class="text-end">
                                            <?php if(isset($d->total_price) && $d->total_price > 0): ?>
                                                <?php echo e(number_format($d->total_price)); ?>

                                            <?php else: ?>
                                                <span class="text-muted">—</span>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td class="text-end">
                                            <?php if(isset($d->amount) && $d->amount > 0): ?>
                                                <?php echo e(number_format($d->amount)); ?>

                                            <?php elseif(isset($d->total_amount) && $d->total_amount > 0): ?>
                                                <?php echo e(number_format($d->total_amount)); ?>

                                            <?php else: ?>
                                                <span class="text-muted">—</span>
                                            <?php endif; ?>
                                        </td>

                                        
                                        <td
                                            class="text-end fw-bold
                                            <?php echo e($d->running_balance > 0 ? 'text-danger' : 'text-success'); ?>">
                                            <?php echo e(number_format($d->running_balance)); ?>

                                        </td>

                                        
                                        <td>
                                            <?php if(isset($d->amount) && $d->amount > 0 && isset($d->id)): ?>
                                                <div class="d-flex gap-1">
                                                    <a href="<?php echo e(route('customer.payment.edit', $d->id)); ?>"
                                                        class="btn btn-sm btn-primary" title="Edit Payment">
                                                        <i class="fa fa-edit"></i>
                                                    </a>
                                                    <form action="<?php echo e(route('customer.payment.destroy', $d->id)); ?>"
                                                        method="POST" style="display:inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-sm btn-danger"
                                                            title="Delete Payment"
                                                            onclick="return confirm('Delete this payment?')">
                                                            <i class="fa fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center text-muted py-4">
                                            No records found for the selected date range.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>

                            <tfoot class="table-light">
                                <tr>
                                    <td colspan="3" class="text-end fw-bold">Totals:</td>
                                    <td class="text-end fw-bold text-danger">
                                        <?php echo e(number_format($debitTotal)); ?>

                                    </td>
                                    <td class="text-end fw-bold text-success">
                                        <?php echo e(number_format($creditTotal)); ?>

                                    </td>
                                    <td
                                        class="text-end fw-bold
                                        <?php echo e($dueTotal > 0 ? 'text-danger' : 'text-success'); ?>">
                                        Due: <?php echo e(number_format($dueTotal)); ?>

                                    </td>
                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>

                        
                        <?php if($ledgerPaginator->hasPages()): ?>
                            <div class="d-flex justify-content-between align-items-center mt-3">
                                <div class="text-muted small">
                                    Showing
                                    <strong><?php echo e($ledgerPaginator->firstItem()); ?></strong>
                                    to
                                    <strong><?php echo e($ledgerPaginator->lastItem()); ?></strong>
                                    of
                                    <strong><?php echo e($ledgerPaginator->total()); ?></strong>
                                    entries
                                </div>
                                <div>
                                    <?php echo e($ledgerPaginator->appends([
                                            'start_date' => $startDate,
                                            'end_date' => $endDate,
                                            'per_page' => $perPage,
                                        ])->links('pagination::bootstrap-4')); ?>

                                </div>
                            </div>
                        <?php else: ?>
                            <div class="text-muted small mt-2">
                                Showing all <?php echo e($ledgerPaginator->total()); ?> entries
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const startDate = document.getElementById('start_date');
            const endDate = document.getElementById('end_date');

            if (startDate && endDate) {
                startDate.addEventListener('change', function() {
                    endDate.min = this.value;
                });
                endDate.addEventListener('change', function() {
                    startDate.max = this.value;
                });
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mhanamco/anikafabrics.com/resources/views/customer/cus_ledger.blade.php ENDPATH**/ ?>
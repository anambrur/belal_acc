<?php $__env->startSection('title'); ?>
    Category List
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="page-header">
                <div class="page-title">
                    <h4>Product Company list</h4>
                    <h6>View/Search product Company</h6>
                </div>
                <div class="page-btn">

                </div>
            </div>

            <hr>
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                   

                    <div class="card" id="filter_inputs">
                        <div class="card-body pb-0">

                        </div>
                    </div>

                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Employee</th>
                                <?php for($day = 1; $day <= 31; $day++): ?>
                                    <th><?php echo e($day); ?></th>
                                <?php endfor; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($employee->first_name); ?></td>
                                    <?php for($day = 1; $day <= 31; $day++): ?>
                                        <?php
                                            $status = 'A';
                                            foreach ($attendances as $attendance) {
                                                $punchDate = \Carbon\Carbon::parse($attendance->punch_time);
                                                if ($attendance->emp_code == $employee->id && $punchDate->day == $day) {
                                                    if (
                                                        $attendance->punch_state == 0 ||
                                                        $attendance->punch_state == 4
                                                    ) {
                                                        $status = 'P';
                                                    } elseif (
                                                        $attendance->punch_state == 1 ||
                                                        $attendance->punch_state == 5
                                                    ) {
                                                        $status = 'A';
                                                    }
                                                    break;
                                                }
                                            }
                                        ?>
                                        <td class="<?php echo e($status == 'P' ? 'text-success' : 'text-danger'); ?>">
                                            <?php echo $status == 'P'
                                                ? '<i class="fa-solid fa-check fa-lg" style="color: #00ad1d;"></i>'
                                                : ($status == 'A'
                                                    ? '<i class="fa-solid fa-xmark fa-flip-both fa-lg" style="color: #ff0000;"></i>'
                                                    : ''); ?>

                                        </td>
                                    <?php endfor; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mahamudulhasananam/Projects/belal_accounting/resources/views/attendence/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title'); ?>
    Purchase Add
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="page-header">
                <div class="page-title">
                    <h4>Purchase Add</h4>
                    <h6>Add/Update Purchase</h6>
                </div>
            </div>
            <form action="<?php echo e(route('purchase.store')); ?>" method="post" id="jqvalidation">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 col-lg-4">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label>Supplier Name</label>
                                            <select class="select" name="supplier_id">
                                                <option value="">Choose Supplier</option>
                                                <?php $__empty_1 = true; $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($d->id); ?>"><?php echo e($d->supplier_name); ?>

                                                        (<?php echo e($d->location->address); ?>)
                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <?php endif; ?>
                                            </select>
                                            <div class="text-danger">
                                                <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo e($message); ?>

                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label>Purchase Date </label>
                                            <div class="input-groupicon">
                                                <input type="text" value="" name="date" placeholder="DD-MM-YYYY"
                                                    id="datetimepicker" />
                                                <div class="addonset">
                                                    <img src="<?php echo e(asset('assets/img/icons/calendars.svg')); ?>"
                                                        alt="img" />
                                                </div>
                                                <div class="text-danger">
                                                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <?php echo e($message); ?>

                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <label>Accounts</label>
                                            <select class="select" name="accounts_id" id="paymentMethod_data">
                                                <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <option value="<?php echo e($d->id); ?>" data-balance="<?php echo e($d->amount); ?>">
                                                        <?php echo e($d->bank_name); ?> (Balance: <?php echo e($d->amount); ?>)
                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <option>No accounts available</option>
                                                <?php endif; ?>
                                            </select>
                                            <div class="text-danger">
                                                <?php $__errorArgs = ['product_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo e($message); ?>

                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="col-md-7 offset-1">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="total-order">
                                            <ul>
                                                <li class="total">
                                                    <div class="input-group">
                                                        <h4>Sub Total</h4>
                                                        <span class="input-group-text">৳</span>

                                                        <div>
                                                            <input type="text" value="0" name="sub_total"
                                                                id="sub_total" class="form-control"
                                                                aria-label="Amount (to the nearest dollar)">
                                                        </div>

                                                    </div>
                                                </li>
                                                <li class="total">
                                                    <div class="input-group">
                                                        <h4>Discount</h4>
                                                        <span class="input-group-text">৳</span>
                                                        <div>
                                                            <input type="text" value="0" name="discount_price"
                                                                id="discount_price" class="form-control"
                                                                aria-label="Amount (to the nearest dollar)">
                                                        </div>
                                                        <div class="text-danger">
                                                            <?php $__errorArgs = ['discount_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <?php echo e($message); ?>

                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>

                                                    </div>
                                                </li>
                                                <li class="total">
                                                    <div class="input-group">
                                                        <h4>Total</h4>
                                                        <span class="input-group-text">৳</span>
                                                        <div>
                                                            <input type="text" value="0" name="total_price"
                                                                id="total_price" class="form-control"
                                                                aria-label="Amount (to the nearest dollar)">
                                                        </div>
                                                        <div class="text-danger">
                                                            <?php $__errorArgs = ['total_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <?php echo e($message); ?>

                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </li>

                                                <li class="total">
                                                    <div class="input-group">
                                                        <h4>Paid</h4>
                                                        <span class="input-group-text">৳</span>
                                                        <div>
                                                            <input type="text" value="0" name="paid_amount"
                                                                id="paid_amount" class="form-control"
                                                                aria-label="Amount (to the nearest dollar)">
                                                        </div>
                                                        <div class="text-danger">
                                                            <?php $__errorArgs = ['paid_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <?php echo e($message); ?>

                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </li>
                                                <span id="error_due"></span>

                                                <li class="total">
                                                    <div class="input-group">
                                                        <h4>Due</h4>
                                                        <span class="input-group-text">৳</span>
                                                        <div><input type="text" value="0" name="due"
                                                                id="due" class="form-control"
                                                                aria-label="Amount (to the nearest dollar)">
                                                        </div>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">

                            <div class="col-lg-12 text-end">
                                <hr>
                                <button class="btn btn-submit me-2">Submit</button>
                                <a href="" class="btn btn-cancel">Cancel</a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        let laram = 1;
        $(document).ready(function() {
            $('#paymentMethod_data').on('change', function() {
                const selectedAccountId = $(this).val();
                const selectedAccountOption = $(this).find(':selected');
                const accountBalance = parseFloat(selectedAccountOption.data('balance')) || 0;

                // Log for debugging
                console.log('Selected Account ID:', selectedAccountId);
                console.log('Account Balance:', accountBalance);

                const paidAmountInput = $('#paid_amount');
                const errorMsg = $('<span class="text-danger text-end"></span>');
                errorMsg.appendTo($('#error_due'));


                paidAmountInput.on('input', function() {
                    const enteredAmount = parseFloat(paidAmountInput.val()) || 0;

                    // Clear any previous error messages
                    errorMsg.text('');

                    // Check if the entered amount exceeds the balance
                    if (enteredAmount > accountBalance) {
                        errorMsg.text('Paid amount cannot exceed account balance of ৳' +
                            accountBalance);
                        paidAmountInput.val(
                            accountBalance);
                    }
                });
            });
        });
    </script>
    <script src="<?php echo e(asset('assets/js/custome_add_purchase.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<script>
    var laravelData = <?php echo json_encode($product, 15, 512) ?>;
</script>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mhanamco/anikafabrics.com/resources/views/purchase/purchase_add.blade.php ENDPATH**/ ?>
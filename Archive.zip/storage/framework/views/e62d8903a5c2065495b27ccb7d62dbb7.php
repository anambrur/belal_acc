<?php $__env->startSection('title'); ?>
    Product List
<?php $__env->stopSection(); ?>



<?php $__env->startPush('css'); ?>
    <style>
        @media print {

            /* Ensure the table takes up the full width and retains structure */
            table {
                width: 100%;
                border-collapse: collapse;
                table-layout: fixed;
            }

            /* Adjust column widths to fit the content */
            table th,
            table td {
                padding: 5px;
                border: 1px solid #ddd;
                word-wrap: break-word;
            }

            /* Hide non-print elements */
            #dataTable_wrapper .dt-buttons,
            #dataTable_wrapper .dataTables_filter,
            #dataTable_wrapper .dataTables_length,
            #dataTable_wrapper .dataTables_info,
            #dataTable_wrapper .dataTables_paginate {
                display: none;
            }

            /* Ensure the table header repeats on each new page */
            table thead {
                display: table-header-group;
            }

            /* Flexbox layout for the print page */
            .print-container {
                display: flex;
                width: 100%;
            }

            .print-column {
                width: 50%;
                box-sizing: border-box;
                padding: 10px;
            }

            .print-table {
                width: 100%;
                border-collapse: collapse;
                table-layout: fixed;
            }
        }
    </style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content">
            <div class="page-header">
                <div class="page-title">
                    <h4>Product List</h4>
                    <h6>Manage your products</h6>
                </div>
                <div class="page-btn">
                    <a href="<?php echo e(route('product.create')); ?>" class="btn btn-added"><img
                            src="<?php echo e(asset('assets/img/icons/plus.svg')); ?>" alt="img" class="me-1" />Add New Product</a>
                </div>
            </div>

            <hr>
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('success')); ?>

                </div>
                <script>
                    setTimeout(function() {
                        $('.alert-success').fadeOut('slow');
                    }, 2000);
                </script>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <div class="table-top m-0">
                        <div class="search-set">
                            <div class="search-path">
                                <a class="btn btn-filter" id="filter_search">
                                    <img src="<?php echo e(asset('assets/img/icons/filter.svg')); ?>" alt="img" />
                                    <span><img src="<?php echo e(asset('assets/img/icons/closes.svg')); ?>" alt="img" /></span>
                                </a>
                            </div>
                            <div class="search-input">
                                <a class="btn btn-searchset"><img src="<?php echo e(asset('assets/img/icons/search-white.svg')); ?>"
                                        alt="img" /></a>
                            </div>
                        </div>
                    </div>

                    <div class="card mb-0" id="filter_inputs">
                        <div class="card-body pb-0">
                            <div class="row">
                                <div class="col-lg col-sm-6 col-12">
                                    <div class="form-group">
                                        <select class="select" id="filter_company">
                                            <option>All Company</option>
                                            <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($d->id); ?>"><?php echo e($d->company_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg col-sm-6 col-12">
                                    <div class="form-group">
                                        <select class="select" id="filter_category">
                                            <option>All Category</option>
                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($d->id); ?>"><?php echo e($d->category); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-lg col-sm-6 col-12">
                                    <div class="form-group">
                                        <select class="select" id="filter_batch">
                                            <option>All Batch</option>
                                            <?php $__currentLoopData = $batch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($d->id); ?>"><?php echo e($d->batch_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table datanew data-table" id="dataTable">
                            <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Product Name</th>
                                    <th>Name</th>
                                    <th>Company</th>
                                    <th>Category</th>
                                    <th>unit</< /th>
                                    <th>Batch</th>
                                    <th>Price</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>




<?php $__env->startPush('js'); ?>
    <script type="text/javascript">
        $(document).ready(function() {
            $("#dataTable").DataTable().destroy();
            var table = $(".data-table").DataTable({
                processing: true,
                serverSide: true,
                responsive: true,
                ajax: {
                    url: "<?php echo e(route('productListTable')); ?>",
                    data: function(d) {
                        d.filter_company = $('#filter_company').val();
                        d.filter_category = $('#filter_category').val();
                        d.filter_batch = $('#filter_batch').val();
                    }
                },

                columns: [{
                        data: "sl",
                        name: "sl"
                    },
                    {
                        data: "product_name",
                        name: "product_name"
                    },
                    {
                        data: "bn_name",
                        name: "bn_name"
                    },
                    {
                        data: "company.company_name",
                        name: "company.company_name"
                    },
                    {
                        data: "category.category",
                        name: "category.category"
                    },
                    {
                        data: "unit.unit",
                        name: "unit.unit"
                    },
                    {
                        data: "batch.batch_name",
                        name: "batch.batch_name"
                    },
                    {
                        data: "price",
                        name: "price"
                    },
                    {
                        data: "action",
                        name: "action",
                        orderable: false,
                        searchable: false
                    },
                ],

                dom: "<'row'<'col-sm-12 col-md-3'B><'col-sm-12 col-md-9'f>>" +
                     "<'row'<'col-sm-12'tr>>" +
                     "<'row'<'col-sm-12 col-md-3'i><'col-sm-12 col-md-9'p>>",
                buttons: [{
                        extend: 'copy',
                        text: 'Copy',
                        titleAttr: 'Copy'
                    },
                    {
                        extend: 'excel',
                        text: 'Excel',
                        titleAttr: 'Excel'
                    },
                    {
                        extend: 'pdf',
                        text: 'PDF',
                        titleAttr: 'PDF'
                    },
                    {
                        extend: 'print',
                        text: 'Print',
                        titleAttr: 'Print',
                        customize: function(win) {
                            var body = $(win.document.body);
                            body.addClass('print-container');

                            var table = body.find('table').clone().addClass('print-table');

                            // Clear body and add flex columns
                            body.empty().append(
                                '<div class="print-column"></div><div class="print-column"></div>'
                                );

                            // Append table to first column
                            var column1 = body.find('.print-column').first();
                            column1.append(table);

                            // Optionally, add logic to handle table overflow if needed

                            // Set font size for printing
                            body.css('font-size', '10pt');
                        },
                        exportOptions: {
                            columns: [0, 2, 7] // Adjust as needed
                        }
                    }
                ]
            });

            $(".select").select2();
            $('#filter_company, #filter_category, #filter_batch').change(function() {
                table.draw();
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mahamudulhasananam/Projects/belal_accounting/resources/views/product/product_list.blade.php ENDPATH**/ ?>